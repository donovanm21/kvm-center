from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any
import sqlite3
from datetime import datetime
import uvicorn

app = FastAPI(title="KVM-Center Control Plane")

# --- Database Setup ---
DB_PATH = "/data/kvm_center.db"

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS hosts (
                host_id TEXT PRIMARY KEY,
                last_seen TIMESTAMP,
                cpu_usage REAL,
                mem_usage REAL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS vms (
                vm_id TEXT PRIMARY KEY,
                host_id TEXT,
                name TEXT,
                state TEXT,
                cpu INTEGER,
                mem INTEGER,
                last_updated TIMESTAMP,
                FOREIGN KEY(host_id) REFERENCES hosts(host_id)
            )
        """)
        conn.commit()

@app.on_event("startup")
def startup_event():
    init_db()

# --- Models ---
class VMTelemetry(BaseModel):
    name: str
    id: str
    state: str
    cpu: int
    mem: int

class HostTelemetry(BaseModel):
    host_id: str
    cpu_usage: float
    mem_usage: float
    vms: List[VMTelemetry]
    timestamp: str

# --- API Endpoints ---

@app.post("/api/telemetry")
async def receive_telemetry(data: HostTelemetry):
    try:
        with sqlite3.connect(DB_PATH) as conn:
            # Update Host State
            conn.execute(
                "INSERT INTO hosts (host_id, last_seen, cpu_usage, mem_usage) VALUES (?, ?, ?, ?) "
                "ON CONFLICT(host_id) DO UPDATE SET last_seen=excluded.last_seen, cpu_usage=excluded.cpu_usage, mem_usage=excluded.mem_usage",
                (data.host_id, data.timestamp, data.cpu_usage, data.mem_usage)
            )
            
            # Update VM States
            for vm in data.vms:
                conn.execute(
                    "INSERT INTO vms (vm_id, host_id, name, state, cpu, mem, last_updated) VALUES (?, ?, ?, ?, ?, ?, ?) "
                    "ON CONFLICT(vm_id) DO UPDATE SET state=excluded.state, last_updated=excluded.last_updated",
                    (vm.id, data.host_id, vm.name, vm.state, vm.cpu, vm.mem, data.timestamp)
                )
            conn.commit()
        return {"status": "ok"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/hosts")
async def list_hosts():
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        cursor = conn.execute("SELECT * FROM hosts")
        return [dict(row) for row in cursor.fetchall()]

@app.get("/api/vms")
async def list_vms():
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        cursor = conn.execute("SELECT * FROM vms")
        return [dict(row) for row in cursor.fetchall()]

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
